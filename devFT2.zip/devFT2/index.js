// GEOMAP


google.charts.load('current', {
  'packages':['geochart'],
  'mapsApiKey': 'AIzaSyD-9tSrke72PouQMnMX-a7eZSW0jkFMBWY'
});

google.charts.setOnLoadCallback(drawVisualisation);

function drawVisualisation() {
  var data = google.visualization.arrayToDataTable([
    ['Country', 'Number of gamers'],
    ['China', 152937],
    ['United States', 20753],
    ['Brazil', 4796],
    ['Canada', 12869],
    ['France', 3754],
  ]);

  var options = {
    colorAxis: {colors: ['red', 'orange', 'yellow', 'green', 'blue', 'purple']},
    backgroundColor: 'none',
    datalessRegionColor: '#e0ca91',
    defaultColor: '#e0ca91',
  };

  var chart = new google.visualization.GeoChart(document.getElementById('geomap'));

  chart.draw(data, options);
}  

